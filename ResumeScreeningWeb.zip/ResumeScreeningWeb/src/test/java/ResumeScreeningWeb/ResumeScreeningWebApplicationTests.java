package ResumeScreeningWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResumeScreeningWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
