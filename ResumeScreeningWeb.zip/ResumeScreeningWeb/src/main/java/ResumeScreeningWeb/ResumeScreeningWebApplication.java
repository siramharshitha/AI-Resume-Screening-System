package ResumeScreeningWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResumeScreeningWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResumeScreeningWebApplication.class, args);
	}

}
